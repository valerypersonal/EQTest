USE [EQPlayers]
GO

/****** Object:  Table [dbo].[Players]    Script Date: 30/11/2018 1:21:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Players](
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Age] [int] NULL,
	[Skill] [varchar](20) NULL,
	[Email] [varchar](100) NULL,
	[PlayerID] [uniqueidentifier]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


