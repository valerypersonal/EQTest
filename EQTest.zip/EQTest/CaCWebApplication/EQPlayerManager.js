﻿var EQPlayerManager = angular.module("EQManagerApp", []);
EQPlayerManager.controller("EQManagerCont", function ($scope, $http) {
    $scope.EQUserBaseURL       = "http://ocdt70367353.office.adroot.bmogc.net/EQPlayerServer/EQPlayerService.svc/";
    $scope.EQUserCurrent       = {};
    $scope.EQUserDefault       = {
        PlayerID    :"0",
        FirstName   :"",
        LastName    :"",
        Age         :"",
        Email       :"",
        Skill       :""
    };
    $scope.EQUserCheckedList   = [];
    $scope.EQUsersLoaded       = false;
    $scope.EQUserBtnPressed    = "";

    $scope.addinBtnShow        = [];
    $scope.debugsShow          = [];

    $scope.addinBtnPressed  = false;
    $scope.debugsPressed    = false;
    $scope.optionsSkill     = [{ name: " "          , id: 0 },
                               { name: "Beginner"   , id: 1 },
                               { name: "Intermediate",id: 2 },
                               { name: "Advanced"   , id: 3 },
                               { name: "Expert"     , id: 4 }];
    $scope.selectedSkill    = {};
    $scope.resultMessage    = "";
    $scope.resultCode       = 0;

    $scope.orderByUser      = function (x) {
        $scope.userOrderBy = x;
        $scope.userReversed = !$scope.userReversed;
    }

    //*************************************** EQ User REST Accesss Methods *****************************
    $scope.getEQUsers      = function () {
        try {
            var httpRequest = $http({
                method: "GET",
                url: $scope.EQUserBaseURL + "all",
                dataType: 'json',
                data: {}, 
                headers: {"Content-Type": "application/json" }
            }).then(function (response) {
                $scope.EQUsersLoaded = true;
                $scope.EQUserList = angular.fromJson(response.data);
                $scope.EQUserCheckedList = [];
                $scope.resultCode = 0;
            }, function (error) {
                showMessage("errorTextRed", "Error getting user data. Message: " + error.data.Message + " Status: " + error.status + "; Status Text: " + error.statusText);
                showError(error.data);
                $scope.EQUserList = error;
                $scope.resultCode = 1;
            });
        }
        catch (e) {
            showMessage("errorTextRed", "Exception getting user data: " + e.message);
        }
    };
    $scope.addEQUsers      = function () {
        try {
            var httpRequest = $http({
                method: "GET",
                url: $scope.EQUserBaseURL   + $scope.EQUserCurrent.PlayerID + "/add?" +
                            "FirstName="    + $scope.EQUserCurrent.FirstName + "&" +
                            "LastName="     + $scope.EQUserCurrent.LastName + "&" +
                            "Age="          + $scope.EQUserCurrent.Age + "&" +
                            "Email="        + $scope.EQUserCurrent.Email + "&" +
                            "Skill="        + $scope.selectedSkill.name,
                dataType: 'json',
                data: {},
                headers: { "Content-Type": "application/json" }
            }).then(function (response) {
                $scope.resultMessage = response.data;
                $scope.resultCode = 0;
            }, function (error) {
                showMessage("errorTextRed", "Error adding new user. Message: " + error.data.Message + " Status: " + error.status + "; Status Text: " + error.statusText);
                showError(error.data);
                $scope.resultMessage = error.data;
                $scope.resultCode = 1;
            });
        }
        catch (e) {
            showMessage("errorTextRed", "Exception adding new user: " + e.message);
        }
    };
    $scope.delEQUsers      = function () {
        try {
            var httpRequest = $http({
                method: "GET",
                url: $scope.EQUserBaseURL + $scope.EQUserCurrent.PlayerID + "/delete",
                dataType: 'json',
                data: {},
                headers: { "Content-Type": "application/json" }
            }).then(function (response) {
                $scope.resultMessage = response.data;
                $scope.resultCode = 0;
            }, function (error) {
                showMessage("errorTextRed", "Error deleting users. Message: " + error.data.Message + " Status: " + error.status + "; Status Text: " + error.statusText);
                showError(error.data);
                $scope.resultMessage = error.data;
                $scope.resultCode = 1;
            });
        }
        catch (e) {
            showMessage("errorTextRed", "Exception deleting users: " + e.message);
        }
    };

    //***************************************** EQ User Update Methods ****************************
    $scope.setSelectedAll = function () {
        $scope.selectedSkill = $scope.optionsSkill.find(function (x) { return x.name == $scope.EQUserCurrent.Skill })
        if ($scope.selectedSkill == null)
            $scope.selectedSkill = $scope.optionsSkill[0];
    }
    $scope.addNewUser       = function () {
        $scope.EQUserBtnPressed = "new";
        $scope.EQUserCurrent = $scope.EQUserDefault;
        if ($scope.EQUserCheckedList.length > 0) {
            var found = $scope.EQUserList.find(function (x) { return x.PlayerID == $scope.EQUserCheckedList[0]; });
            if (found != null)
                $scope.EQUserCurrent = found;
        }
        $scope.setSelectedAll();
        positionEditUser();
    }
    $scope.editSelUsers     = function () {
        if ($scope.EQUserCheckedList.length == 0) {
            alert("Please, select users you'd like to edit.");
        } else {
            var found = $scope.EQUserList.find(function (x) { return x.PlayerID == $scope.EQUserCheckedList[0]; });
            if (found != null) {
                $scope.EQUserCurrent = found;
                if ($scope.EQUserCheckedList.length == 1)
                    $scope.EQUserBtnPressed = "sel";
                else {
                    $scope.EQUserBtnPressed = "selm";
                    $scope.EQUserCurrent.FirstName = "";
                    $scope.EQUserCurrent.LastName = "";
                    $scope.EQUserCurrent.Age = "";
                    $scope.EQUserCurrent.Email = "";
                    $scope.EQUserCurrent.Skill = "";
                }
                $scope.setSelectedAll();
                positionEditUser();
            } else
                showMessage("errorTextRed", "Unable to find selected users.");
        }
    }
    $scope.delSelUsers      = function () {
        if ($scope.EQUserCheckedList.length == 0) {
            alert("Please, select users you'd like to delete.");
        } else {
            if (confirm("The following users will be deleted: \n " + $scope.EQUserCheckedList + ".\n Proceed?")) {
                $scope.EQUserCurrent.PlayerID = $scope.EQUserCheckedList;
                $scope.delEQUsers();
                if ($scope.resultCode == 0) 
                    showMessage("errorTextGreen", "Users " + $scope.EQUserCheckedList + " were successfully deleted.");
            }
        }
    }
    $scope.saveUser         = function () {
        var message = "";

        if ($scope.EQUserCurrent.FirstName == "") {
            showMessage("errorTextRed", "Please, fill up the First Name.");
            return;
        }
        if ($scope.EQUserCurrent.LastName == "") {
            showMessage("errorTextRed", "Please, fill up the Last Name.");
            return;
        }
        if ($scope.EQUserCurrent.Email == "") {
            showMessage("errorTextRed", "Please, fill up the Email.");
            return;
        }
        if ($scope.selectedSkill.name == "" ||
            $scope.selectedSkill.name == " ") {
            showMessage("errorTextRed", "Please, select the Skill.");
            return;
        }
        if ($scope.EQUserCurrent.Email.indexOf("@") == -1 ||
            $scope.EQUserCurrent.Email.indexOf(".") == -1) {
            showMessage("errorTextRed", "Please, check the Email address format.");
            return;
        }
        if ($scope.EQUserCurrent.Age != "" &&
            !(/^\d+$/.test($scope.EQUserCurrent.Age))) {
            showMessage("errorTextRed", "The Age should only have digits in the value.");
            return;
        }

        if ($scope.EQUserBtnPressed == "new") {
            $scope.EQUserCurrent.PlayerID = $scope.EQUserCurrent.PlayerID.split(",").join(" ");
            $scope.addEQUsers();
            message = "New user was succesfully added.";
        } else
        if ($scope.EQUserBtnPressed == "sel" ||
            $scope.EQUserBtnPressed == "selm") {
            if ($scope.EQUserCheckedList.length == 0) {
                alert("Please, select users you'd like to edit.");
            } else {
                $scope.EQUserCurrent.PlayerID = $scope.EQUserCheckedList;
                $scope.addEQUsers();
                message = "Users " + $scope.EQUserCheckedList + " were successfully updated.";
            }
        } else
            return;

        if ($scope.resultCode == 0) showMessage("errorTextGreen", message);
        else                        showMessage("errorTextRed", $scope.resultMessage);
        $scope.EQUserBtnPressed = "";
    }
    $scope.cancelUser       = function () {
        $scope.EQUserBtnPressed = "";
    }
    $scope.userChecked      = function ($event, id) {
        var checkbox = $event.target;
        if (checkbox.checked) {
            $scope.EQUserCheckedList.push(id);
        } else {
            var index = $scope.EQUserCheckedList.indexOf(id);
            if (index > -1)
                $scope.EQUserCheckedList.splice(index, 1);
        }
    }
});
