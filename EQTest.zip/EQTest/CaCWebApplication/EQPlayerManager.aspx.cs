﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Services;
using System.Web.UI.WebControls;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

namespace EQPlayerWebApp
{
    public partial class EQPlayerManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        //[WebMethod()]
        //public static async Task<EQPlayers> getUserList()
        //{
        //    string BaseURL = "";
        //    EQPlayers CaCUserList = new EQPlayers();
        //    string data = "";

        //    try { 

        //        if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["BaseURL"]))
        //                        BaseURL = ConfigurationManager.AppSettings["BaseURL"];
        //        else            BaseURL = "http://ocdt70367353.office.adroot.bmogc.net/cacserver/CaCUsersService.svc/All";

        //        using (HttpClient client = new HttpClient())
        //        {
        //            Uri BaseUri = new Uri(BaseURL);
        //            client.BaseAddress = BaseUri;
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //            HttpResponseMessage response = await client.GetAsync(BaseUri);// dataString);
        //            if (response.IsSuccessStatusCode)
        //            {
        //                data = await response.Content.ReadAsStringAsync();
        //                CaCUserList = JsonConvert.DeserializeObject<EQPlayers>(data);
        //            }
        //            else
        //            {
        //                EQPlayer user = new EQPlayer();
        //                CaCUserList.Add(user);
        //            }
        //        }

        //        return CaCUserList;
        //    }
        //    catch(Exception ex)
        //    {
        //        string error = "There was an error collecting user list from CaCUsersService: " + ex.Message;
        //        return CaCUserList;
        //    }
        //}
    }
}