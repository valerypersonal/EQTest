DROP PROCEDURE dbo.SavePlayer
GO
 
CREATE PROCEDURE dbo.SavePlayer
 
@json NVARCHAR(max)
 
AS
BEGIN
 
@PlayerID int

select
	FirstName, 
	LastName, 
	Age, 
	Skill, 
	Email
from OPENJSON(@json)
with (
    FirstName	varchar(50),
    LastName	varchar(50),
    Age			int,
    Skill		int,
    Email		varchar(100)
) as jsonValues

select @PlayerID = PlayerID
from Players
where FirstName = jsonValues.FirstName
  and LastName = jsonValues.LastName
  
if @PlayerID is null 
insert into dbo.Players (
	FirstName, 
	LastName, 
	Age, 
	Skill, 
	Email
) values (
	jsonValues.FirstName, 
	jsonValues.LastName, 
	jsonValues.Age, 
	jsonValues.Skill, 
	jsonValues.Email
) 
else 
update dbo.Players 
set
	FirstName	= jsonValues.FirstName, 
	LastName	= jsonValues.LastName, 
	Age			= jsonValues.Age, 
	Skill		= jsonValues.Skill, 
	Email		= jsonValues.Email
where PlayerID	= @PlayerID
 
END
GO