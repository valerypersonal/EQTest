DROP PROCEDURE dbo.InsertPlayer
GO
 
CREATE PROCEDURE dbo.InsertPlayer
 
@json NVARCHAR(max)
 
AS
BEGIN
 
INSERT INTO dbo.Players (
	FirstName, 
	LastName, 
	Age, 
	Skill, 
	Email
) 
    SELECT
		FirstName, 
		LastName, 
		Age, 
		Skill, 
		Email
    FROM OPENJSON(@json)
    WITH (
      FirstName	varchar(50),
      LastName	varchar(50),
      Age		int,
      Skill     int,
      Email		varchar(100)
    ) AS jsonValues
 
END
GO