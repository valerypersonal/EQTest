﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using EQPlayerServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace EQPlayerServer.Tests
{
    [TestClass()]
    public class DBProcessingTests
    {
        [TestMethod()]
        public void DBConnectionTest()
        {
            DBProcessing dbProc = new DBProcessing();
            object obj = null;
            obj = dbProc.sqlCommand.ExecuteScalar();
            Assert.IsNotNull(obj);
        }
    }
}