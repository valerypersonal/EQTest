﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace EQPlayerServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IConfig" in both code and config file together.
    [ServiceContract]
    public interface IEQPlayerService
    {
        [OperationContract]
        [WebInvoke( Method = "GET", UriTemplate = "All",
            RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        List<EQPlayer> GetAll();

        [OperationContract]
        [WebInvoke( Method = "GET", UriTemplate = "{PlayerID}",
            RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        EQPlayer GetID(string PlayerID);

        [OperationContract]
        [WebInvoke( Method = "GET", UriTemplate = "{PlayerID}/Add?FirstName={FirstName}&LastName={LastName}&Age={Age}&Email={Email}&Skill={Skill}", 
            RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        string Add(string PlayerID, string FirstName, string LastName, string Age, string Email, string Skill);

        [OperationContract]
        [WebInvoke( Method = "GET", UriTemplate = "{PlayerID}/Update?FirstName={FirstName}&LastName={LastName}&Age={Age}&Email={Email}&Skill={Skill}", 
            RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        string Update(string PlayerID, string FirstName, string LastName, string Age, string Email, string Skill);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "{PlayerID}/Delete",
            RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        string Delete(string PlayerID);
    }
}
