﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Configuration;
using Newtonsoft.Json;

namespace EQPlayerServer
{
    public class EQPlayer
    {
        [DataMember]
        public string PlayerID { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Age { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string Skill { get; set; }
    }
    public class EQPlayers
    {
        public List<EQPlayer> EQPlayerList = new List<EQPlayer>();
        private string EQPlayerFileName = HttpRuntime.AppDomainAppPath + "\\EQPlayers.config";
        public logFileFixer logManager  = new logFileFixer(HttpRuntime.AppDomainAppPath + "\\Logs", CommonShared.logFileBasName, ".log", 10000, 20);

        public EQPlayers()
        {
        }
        /// <summary>
        /// Get all records
        /// </summary>
        /// <returns>List of players</returns>
        public List<EQPlayer> GetAll()
        {
            string loadRes = LoadFromDB();
            if (loadRes != "")
            {
                EQPlayer cacUser = new EQPlayer();
                cacUser.PlayerID = "0";
                EQPlayerList.Add(cacUser);
                return EQPlayerList;
            }
            return EQPlayerList;
        }
        /// <summary>
        /// Get the record by ID
        /// </summary>
        /// <param name="PlayerID">The ID of the player</param>
        /// <returns>Player object</returns>
        public EQPlayer GetID(string PlayerID)
        {
            if (PlayerID == "")
                return null;
            string loadRes = LoadFromDB();
            if (loadRes != "")
                return null; 
            return EQPlayerList.Find(e => e.PlayerID.ToLower() == PlayerID.ToLower());
        }
        /// <summary>
        /// Add or update player data
        /// </summary>
        /// <param name="item">Player object</param>
        /// <returns>The result message</returns>
        public string AddUpdate(EQPlayer item)
        {
            try {
                if (item == null)
                    return "User item is blank.";
                string loadRes = LoadFromDB();
                if (loadRes != "")
                    return loadRes;
                int index = EQPlayerList.FindIndex(e => e.PlayerID.ToLower() == item.PlayerID.ToLower());
                if (index > -1)
                {
                    if (string.IsNullOrEmpty(item.FirstName))   item.FirstName  = EQPlayerList[index].FirstName;
                    if (string.IsNullOrEmpty(item.LastName))    item.LastName   = EQPlayerList[index].LastName;
                    if (string.IsNullOrEmpty(item.Age))         item.Age        = EQPlayerList[index].Age;
                    if (string.IsNullOrEmpty(item.Email))       item.Email      = EQPlayerList[index].Email;
                    if (string.IsNullOrEmpty(item.Skill))       item.Skill      = EQPlayerList[index].Skill;
                    EQPlayerList.RemoveAt(index);
                }

                EQPlayerList.Add(item);
                if (SaveToDB())
                    return "User item was added/updated successfully.";
                else
                    return "Was unable to save user items.";
            } catch (Exception ex)
            {
                return "There was an error adding/updating user: " + ex.Message;
            }
        }
        /// <summary>
        /// Deletes the record
        /// </summary>
        /// <param name="PlayerID">The ID of the Player to be deleted</param>
        /// <returns>The result message</returns>
        public string Delete(string PlayerID)
        {
            try {
                if (PlayerID == "")
                    return "User item PlayerID is blank.";
                string loadRes = LoadFromDB();
                if (loadRes != "")
                    return loadRes; 
                int index = EQPlayerList.FindIndex(e => e.PlayerID.ToLower() == PlayerID.ToLower());
                if (index == -1)
                    return "User item " +PlayerID+ " does not exist.";
                EQPlayerList.RemoveAt(index);
                if (SaveToDB())
                    return "User item was deleted successfully.";
                else
                    return "Was unable to save user items.";
            } catch (Exception ex)
            {
                return "There was an error deleting user: " + ex.Message;
            }
        }
        /// <summary>
        /// Saves data to DB
        /// </summary>
        /// <returns>Success or failure</returns>
        private bool SaveToDB()
        {
            return SaveToFile();                //save data to a file while testing

            try {
                logManager.saveLogREST("Saved");
                string json = JsonConvert.SerializeObject(EQPlayerList.ToArray());
                DBProcessing dbProc = new DBProcessing();
                if (dbProc.SaveData(json) != "")
                    return SaveToFile();
                return true;
            } catch
            {
                return false;
            }
        }
        /// <summary>
        /// Saves data to file
        /// </summary>
        /// <returns>Success or failure</returns>
        private bool SaveToFile()
        {
            try {
                logManager.saveLogREST("Saved");
                string json = JsonConvert.SerializeObject(EQPlayerList.ToArray());
                System.IO.File.WriteAllText(EQPlayerFileName, json);
                return true;
            } catch
            {
                return false;
            }
        }
        /// <summary>
        /// Loads data from DB
        /// </summary>
        /// <returns>Blank or error message</returns>
        private string LoadFromDB()
        {
            return LoadFromFile();          //read adata from file while testing

            DBProcessing dbProc = new DBProcessing();
            string json = "";
            string error = dbProc.GetData(ref json);
            if (error == "")
            {
                if (json != "")
                    EQPlayerList = JsonConvert.DeserializeObject<List<EQPlayer>>(json);
            } 
            else
                error = LoadFromFile();

            return error;
        }
        /// <summary>
        /// Loads data from file (overloaded)
        /// </summary>
        /// <returns>Blank or error message</returns>
        private string LoadFromFile()
        {
            return LoadFromFile("");
        }
        /// <summary>
        /// Loads data from file (overloaded)
        /// </summary>
        /// <param name="FROM"></param>
        /// <returns>Blank or error message</returns>
        private string LoadFromFile(string FROM)
        {
            System.IO.StreamReader reader = null;
            string json = "";
            string reqType = FROM;
            try {

                if (!System.IO.File.Exists(EQPlayerFileName))
                     System.IO.File.WriteAllText(EQPlayerFileName, "");
                reader = new System.IO.StreamReader(EQPlayerFileName);
                if (reader == null)
                    return "Could not open user file.";
                json = reader.ReadToEnd();
                if (json != "")
                    EQPlayerList = JsonConvert.DeserializeObject<List<EQPlayer>>(json);
                return "";
            } catch (Exception ex)
            {
                return "There was an error loading from file: " + ex.Message;
            } finally
            {
                if (reqType == "")
                    reqType = "Loaded";
                logManager.saveLogREST(reqType);

                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }
            }
        }
    }
}