﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web;

namespace EQPlayerServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Config" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Config.svc or Config.svc.cs at the Solution Explorer and start debugging.
    public class EQPlayerService : IEQPlayerService
    {
        EQPlayers eqPlayers = new EQPlayers();
        /// <summary>
        /// Gets all records
        /// </summary>
        /// <returns>List of player objects</returns>
        public List<EQPlayer> GetAll()
        {
            return eqPlayers.GetAll();
        }
        /// <summary>
        /// Gets the record by ID
        /// </summary>
        /// <param name="PlayerID">The player ID</param>
        /// <returns>Player object</returns>
        public EQPlayer GetID(string PlayerID)
        {
            return eqPlayers.GetID(PlayerID);
        }
        public string Add(string PlayerID, string FirstName, string LastName, string Age, string Email, string Skill)
        {
            eqPlayers.logManager.saveLogREST("EQPlayerService.Add");
            if (PlayerID.IndexOf(",") == -1)
            {
                EQPlayer config = new EQPlayer { PlayerID = PlayerID, FirstName = FirstName, LastName = LastName, Age = Age, Email = Email, Skill = Skill};
                return eqPlayers.AddUpdate(config);
            } else  {
                string res = "";
                List<string> idList = new List<string>();
                idList = PlayerID.Split(',').ToList();
                foreach (string id in idList)
                {
                    EQPlayer config = new EQPlayer { PlayerID = id, FirstName = FirstName, LastName = LastName, Age = Age, Email = Email, Skill = Skill};
                    res = eqPlayers.AddUpdate(config);
                }
                return res;
            }
        }
        public string Update(string PlayerID, string FirstName, string LastName, string Age, string Email, string Skill)
        {
            if (PlayerID.IndexOf(",") == -1)
            {
                EQPlayer config = new EQPlayer { PlayerID = PlayerID, FirstName = FirstName, LastName = LastName, Age = Age, Email = Email, Skill = Skill };
                return eqPlayers.AddUpdate(config);
            } else  {
                string res = "";
                List<string> idList = new List<string>();
                idList = PlayerID.Split(',').ToList();
                foreach (string id in idList)
                {
                    EQPlayer config = new EQPlayer { PlayerID = id, FirstName = FirstName, LastName = LastName, Age = Age, Email = Email, Skill = Skill };
                    res = eqPlayers.AddUpdate(config);
                }
                return res;
            }
        }
        public string Delete(string PlayerID)
        {
            if (PlayerID.IndexOf(",") == -1)
                return eqPlayers.Delete(PlayerID);
            else  {
                string res = "";
                List<string> idList = new List<string>();
                idList = PlayerID.Split(',').ToList();
                foreach (string id in idList)
                {
                    res = eqPlayers.Delete(id);
                }
                return res;
            }
        }
    }
}
