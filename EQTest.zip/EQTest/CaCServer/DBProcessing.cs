﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;


namespace EQPlayerServer
{
    public class DBProcessing
    {
        private SqlConnection   sqlConnection   = null;
        private string connStr      = "Data Source=ocdt70367353\\sql2014;Initial Catalog=EQPlayers;Integrated Security=True";
        private string sqlQuery     = "select * from Players FOR JSON AUTO";
        private string saveProc     = "SavePlayer";
        private string insertProc   = "InsertPlayer";
        private string updateProc   = "UpdatePlayer";

        public SqlCommand      sqlCommand      = null;
        public SqlDataReader   sqlReader       = null;

        public DBProcessing() {
                sqlConnection = new SqlConnection();
                sqlCommand = new SqlCommand();
                sqlConnection.ConnectionString = connStr;
                sqlCommand.Connection = sqlConnection;
                sqlConnection.Open();
        }
        /// <summary>
        /// Get data from database
        /// </summary>
        /// <param name="jsonData">Data string in json format</param>
        /// <returns>Blank or error massage</returns>
        public string GetData(ref string jsonData)
        {
            try
            {
                sqlCommand.CommandText = sqlQuery;
                sqlReader = sqlCommand.ExecuteReader();

                if (!sqlReader.HasRows)
                {
                    jsonData = "[]";
                }
                else
                {
                    while (sqlReader.Read())
                    {
                        jsonData += sqlReader.GetValue(0).ToString();
                    }
                }

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                CloseConnection();
            }
        } 
        /// <summary>
        /// Saves (inserts or updates) data to the database
        /// </summary>
        /// <param name="jsonData">Data string in json format</param>
        /// <returns>Blank or error massage</returns>
        public string SaveData(string jsonData)
        {
            try
            {
                sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCommand.CommandText = saveProc;
                sqlCommand.Parameters.Add(new SqlParameter("@json", jsonData));
                sqlReader = sqlCommand.ExecuteReader();

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                CloseConnection();
            }
        }
        /// <summary>
        /// Inserts record to the database
        /// </summary>
        /// <param name="jsonData">Data string in json format</param>
        /// <returns>Blank or error massage</returns>
        public string InsertData(string jsonData)
        {
            try
            {
                sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCommand.CommandText = insertProc;
                sqlCommand.Parameters.Add(new SqlParameter("@json", jsonData));
                sqlReader = sqlCommand.ExecuteReader();

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                CloseConnection();
            }
        }
        /// <summary>
        /// Updates record in the database
        /// </summary>
        /// <param name="jsonData">Data string in json format</param>
        /// <returns>Blank or error massage</returns>
        public string UpdateData(string jsonData)
        {
            try
            {
                sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCommand.CommandText = updateProc;
                sqlCommand.Parameters.Add(new SqlParameter("@json", jsonData));
                sqlReader = sqlCommand.ExecuteReader();

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                CloseConnection();
            }
        }
        /// <summary>
        /// Closes connection and reader
        /// </summary>
        private void CloseConnection()
        {
            if (sqlReader != null)
                sqlReader.Close();
            if (sqlConnection != null)
                sqlConnection.Close();
        }
    }
}