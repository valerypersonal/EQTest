﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Web;

namespace EQPlayerServer
{
    public static class CommonShared
    {

        public static string logFileBasName = "EQPlayerServer";
        public static string timFileBasName = "EQPlayerServerTimes";
        public static logFileFixer logManager = null;
        public static logFileFixer timeLogger = null;

        /// <summary>
        /// Compiles the next log file name when the current log file becomes large.
        /// </summary>
        /// <param name="fileNameBase">Base log file name.</param>
        /// <param name="fileExtension">Log file extenasion.</param>
        /// <param name="maxFileNumber">The number of log files kept as a history.</param>
        /// <param name="startFileNumber">The file number to start looking from.</param>
        /// <returns>Next log file name with extension.</returns>
        public static string findNextLogFileName(string fileNameBase, string fileExtension, int maxFileNumber, ref int startFileNumber)
        {
            string curFileName = fileNameBase + startFileNumber.ToString("D2") + fileExtension;
            FileInfo file1 = new FileInfo(curFileName);
            FileInfo file2;
            while (file1.Exists && startFileNumber <= maxFileNumber)
            {
                startFileNumber++;
                curFileName = fileNameBase + startFileNumber.ToString("D2") + fileExtension;
                file2 = new FileInfo(curFileName);
                if (file2.Exists && file2.LastWriteTime < file1.LastWriteTime)
                    break;
                file1 = file2;
            }
            if (startFileNumber <= maxFileNumber)
                return curFileName;
            else
                return fileNameBase + "01" + fileExtension;
        }
    }
    /// <summary>
    /// The class takes care of log file names when file become large.
    /// </summary>
    public class logFileFixer
    {
        //private bool logIsOn = false;
        private string logAge = "";
        private string logBaseName = "";
        private string logFileName = "";
        private string logFileNameLast = "";
        private string logFileExt = ".log";
        private int maxLogFileLength;
        private int maxLogFileNum;
        private int curLogFileLength = 1;
        private int curLogFileNum = 0;
        
        private StreamWriter logT = null;

        public DateTime prevTime;
        public DateTime startTime;
        public bool logIsOn = true;

        /// <summary>
        /// This constructor is specifically for time test printouts
        /// </summary>
        /// <param name="plogFullName"></param>
        /// <param name="pmaxFileLength"></param>
        /// <param name="pmaxFileNum"></param>
        public logFileFixer(string plogFullName, int pmaxFileLength, int pmaxFileNum) : this         
           (Path.GetDirectoryName(plogFullName),
            Path.GetFileNameWithoutExtension(plogFullName),
            Path.GetExtension(plogFullName),
            pmaxFileLength, pmaxFileNum)//, plogIsOn)
        {
            logT = new StreamWriter(plogFullName, true);
        }
        public logFileFixer(string plogPath, string plogBaseName, string plogExt, int pmaxFileLength, int pmaxFileNum)
        { 
            try {
                if (string.IsNullOrEmpty(plogBaseName))
                    return;
                logAge = plogPath;
                if (logAge == null ||
                    logAge == "")
                    logAge = AppDomain.CurrentDomain.BaseDirectory;
                if (!string.IsNullOrEmpty(logAge))
                {
                    if (!logAge.EndsWith("\\")) 
                        logAge += '\\';
                    if (!Directory.Exists(logAge))
                        Directory.CreateDirectory(logAge);
                }

                logBaseName = plogBaseName;
                if (!string.IsNullOrEmpty(plogExt))
                    logFileExt = plogExt;

                logFileName = logAge + logBaseName + logFileExt;
                maxLogFileLength = pmaxFileLength;
                maxLogFileNum = pmaxFileNum;
                //logIsOn = plogIsOn;
                //log = new StreamWriter(logFileName, true);
            }
            catch { }
        }
        /// <summary>
        /// Fixes the log file if it becomes too large
        /// </summary>
        public string fixLogFile()
        {
            StreamReader logRead = null; 
            try {
                curLogFileLength = 1;
                logRead = new StreamReader(logFileName);
                logRead.ReadLine();
                while (!logRead.EndOfStream)
                {
                    logRead.ReadLine();
                    curLogFileLength++;
                }
                if (curLogFileLength >= maxLogFileLength)
                {
                    logFileNameLast = getLogFileName();
                    if (File.Exists(logFileNameLast))
                        File.Delete(logFileNameLast);
                    File.Move(logFileName, logFileNameLast);
                    File.Create(logFileName);
                    return "Log file has been fixed.";
                } else
                    return "No log file fix was required.";
            }
            catch (Exception e) {
                return "There were errors fixing log file: " + e.Message;
            }
            finally {
                if (logRead != null)
                {
                    logRead.Close();
                    logRead.Dispose();
                }
            }
        }
        /// <summary>
        /// Finds file name with increased number in it if the file becomes too large.
        /// </summary>
        /// <returns>New file name.</returns>
        private string getLogFileName()
        {
            try
            {
                curLogFileNum++;
                return CommonShared.findNextLogFileName(logAge + logBaseName + "_", logFileExt, maxLogFileNum, ref curLogFileNum);
            }
            catch 
            {
                return "";
            }
        }
        /// <summary>
        /// First call when performing time tests
        /// </summary>
        /// <param name="startMessage">First message to save.</param>
        public void startTimeTrack(string startMessage, bool showTimeHeader)
        {
            startTime = DateTime.Now;
            prevTime = startTime;

            if (!logIsOn) return;

            if (showTimeHeader)
                saveLog("   Time      from Previous  from Start   Description", false, true, false);
            saveTime(startMessage);
        }
        /// <summary>
        /// Saves massage when performing time tests. It also saves: time with milliseconds, diffrence from previous time, difference from first time.
        /// </summary>
        /// <param name="logMessage">Message to save.</param>
        public void saveTime(string logMessage)
        {
            if (!logIsOn) return;

            StreamWriter log = null;

            try { 
                if (log == null)
                {
                    if (string.IsNullOrEmpty(logFileName))
                        return;
                    else
                    {
                        log = new StreamWriter(logFileName, true);
                        if (log == null)
                            return;
                    }
                }

                DateTime curTime = DateTime.Now;
                TimeSpan timeDif;
                string dat, dif, dif0;
                dat = curTime.Hour.ToString("d2") +':'+ curTime.Minute.ToString("d2") +':'+ curTime.Second.ToString("d2") +'.'+ curTime.Millisecond.ToString("d3");

                timeDif = curTime - prevTime;
                dif = timeDif.Hours.ToString("d2") +':'+ timeDif.Minutes.ToString("d2") +':'+ timeDif.Seconds.ToString("d2") +'.'+ timeDif.Milliseconds.ToString("d3");

                timeDif = curTime - startTime;
                dif0 = timeDif.Hours.ToString("d2") +':'+ timeDif.Minutes.ToString("d2") +':'+ timeDif.Seconds.ToString("d2") +'.'+ timeDif.Milliseconds.ToString("d3");

                log.WriteLine(dat +"  "+ dif +"  "+ dif0 +"  "+ logMessage);
                log.Flush();
                if (curLogFileLength >= maxLogFileLength)
                {
                    fixLogFile();
                }

                prevTime = curTime;
            }
            catch
            {
            }
            finally
            {
                if (log != null)
                {
                    log.Close();
                    log.Dispose();
                }
            }
        }
        /// <summary>
        /// Saves new massage to log file with time.
        /// </summary>
        /// <param name="logMessage">Message to be saved.</param>
        /// <param name="sameLineAndNewAfter">Indicates if space will be added before the massege and new line simbol will be added after.</param>
        public void saveLog(string logMessage, bool sameLineAndNewAfter)
        {
            saveLog(logMessage, sameLineAndNewAfter, sameLineAndNewAfter, true);
        }
        /// <summary>
        /// Saves new massage to log file from REST.
        /// </summary>
        /// <param name="logMessage">Message to be saved.</param>
        /// <param name="sameLineAndNewAfter">Indicates if space will be added before the massege and new line simbol will be added after.</param>
        public void saveLogREST(string logMessage)
        {
            int maxLen = 8;
            int skipLen = maxLen > logMessage.Length ? maxLen - logMessage.Length : 0;
            int dateLen = 23;
            string logStr = "",
                   logStr1 = "";
            logStr = logMessage + new string(' ', skipLen) + " " +
                    System.Web.HttpContext.Current.Request.Url.AbsoluteUri.Replace("%20", " ") + " ***** ";
            logStr1 = "User: " +
                    //System.Web.HttpContext.Current.Request.UserHostName     + " , " + 
                    System.Web.HttpContext.Current.Request.UserHostAddress + " - " +
                    System.Web.HttpContext.Current.Request.UserAgent + " ***** " +
                    //System.Web.HttpContext.Current.Request.UrlReferrer      + " ***** " + 
                    //System.Web.HttpContext.Current.Request.PhysicalPath     + " ***** " + 
                    //System.Web.HttpContext.Current.Request.Path             + " ***** " + 
                    //System.Web.HttpContext.Current.Request.FilePath         + " ***** " + 
                    //System.Web.HttpContext.Current.Request.Browser.Version  + " ***** " + 
                    //System.Web.HttpContext.Current  + " ***** " + 
                    "";
            if (logStr.Length + logStr1.Length >= 1024)
            {
                logStr += new string(' ', 1024 - dateLen - logStr.Length + 1);
                logStr1 = new string(' ', dateLen + maxLen + 1) + logStr1;
            }
            saveLog(logStr + logStr1, false, false, true);
        }
        /// <summary>
        /// Saves new massage to log file.
        /// </summary>
        /// <param name="logMessage">Message to be saved.</param>
        /// <param name="continueSameLine">Indicates if space will be added before the message.</param>
        /// <param name="newLineAfter">Indicates if new line simbol is required after the message.</param>
        /// <param name="addDateTime">if date and time should be added in front of the log message.</param>
        public void saveLog(string logMessage, bool continueSameLine, bool newLineAfter, bool addDateTime)
        {
            StreamWriter log = null;
            try 
            {
                string dat;
                if (addDateTime)
                    //dat = DateTime.Now.ToShortDateString() + " " +
                    //      DateTime.Now.ToLongTimeString() +", ";
                    dat = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +", ";
                else
                    dat = "";
                if (log == null)
                {
                    if (string.IsNullOrEmpty(logFileName))
                        return;
                    else
                    {
                        log = new StreamWriter(logFileName, true);
                        if (log == null)
                            return;
                    }
                }
                string mess = dat + logMessage;
                if (!continueSameLine)
                {
                    curLogFileLength++;
                    log.WriteLine("");
                }
                if (newLineAfter)
                {
                    curLogFileLength++;
                    log.WriteLine(" " + mess);
                }
                else
                    log.Write(" " + mess);

                log.Flush();
                if (curLogFileLength >= maxLogFileLength)
                {
                    fixLogFile();
                }
            }
            catch
            {
            }
            finally
            {
                if (log != null)
                {
                    log.Close();
                    log.Dispose();
                }
            }
        }
        /// <summary>
        /// Disposes log to release the file.
        /// </summary>
        public void Dispose()
        {
            if (logT != null)
            {
                logT.Close();
                logT.Dispose();
            }
        }
        public void DisposeRead()
        {
            //if (logRead != null)
            //{
            //    logRead.Close();
            //    logRead.Dispose();
            //}
        }
    }
}
